// Placeholder for any future image data
export const acneImages = {};
